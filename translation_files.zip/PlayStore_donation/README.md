# Play Store donation folder

PlayStore's strings for the donation version.

Important! You don't need to translate this if you didn't give permission to publish your translation in the donation version.

Also remember to make sure you keep the number of characters under the maximum specified!!! Otherwise I won't be able to publish it.