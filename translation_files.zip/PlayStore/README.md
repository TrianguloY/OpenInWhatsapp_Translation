# Play Store folder

PlayStore's strings.

If you want to translate the strings make sure you keep the number of characters under the maximum specified!!! Otherwise I won't be able to publish it.